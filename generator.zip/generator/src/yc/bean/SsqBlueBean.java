package yc.bean;

import java.math.BigDecimal;

public class SsqBlueBean {
    private BigDecimal expect;

    private Short blue01;

    private Short blue02;

    private Short blue03;

    private Short blue04;

    private Short blue05;

    private Short blue06;

    private Short blue07;

    private Short blue08;

    private Short blue09;

    private Short blue10;

    private Short blue11;

    private Short blue12;

    private Short blue13;

    private Short blue14;

    private Short blue15;

    private Short blue16;

    public BigDecimal getExpect() {
        return expect;
    }

    public void setExpect(BigDecimal expect) {
        this.expect = expect;
    }

    public Short getBlue01() {
        return blue01;
    }

    public void setBlue01(Short blue01) {
        this.blue01 = blue01;
    }

    public Short getBlue02() {
        return blue02;
    }

    public void setBlue02(Short blue02) {
        this.blue02 = blue02;
    }

    public Short getBlue03() {
        return blue03;
    }

    public void setBlue03(Short blue03) {
        this.blue03 = blue03;
    }

    public Short getBlue04() {
        return blue04;
    }

    public void setBlue04(Short blue04) {
        this.blue04 = blue04;
    }

    public Short getBlue05() {
        return blue05;
    }

    public void setBlue05(Short blue05) {
        this.blue05 = blue05;
    }

    public Short getBlue06() {
        return blue06;
    }

    public void setBlue06(Short blue06) {
        this.blue06 = blue06;
    }

    public Short getBlue07() {
        return blue07;
    }

    public void setBlue07(Short blue07) {
        this.blue07 = blue07;
    }

    public Short getBlue08() {
        return blue08;
    }

    public void setBlue08(Short blue08) {
        this.blue08 = blue08;
    }

    public Short getBlue09() {
        return blue09;
    }

    public void setBlue09(Short blue09) {
        this.blue09 = blue09;
    }

    public Short getBlue10() {
        return blue10;
    }

    public void setBlue10(Short blue10) {
        this.blue10 = blue10;
    }

    public Short getBlue11() {
        return blue11;
    }

    public void setBlue11(Short blue11) {
        this.blue11 = blue11;
    }

    public Short getBlue12() {
        return blue12;
    }

    public void setBlue12(Short blue12) {
        this.blue12 = blue12;
    }

    public Short getBlue13() {
        return blue13;
    }

    public void setBlue13(Short blue13) {
        this.blue13 = blue13;
    }

    public Short getBlue14() {
        return blue14;
    }

    public void setBlue14(Short blue14) {
        this.blue14 = blue14;
    }

    public Short getBlue15() {
        return blue15;
    }

    public void setBlue15(Short blue15) {
        this.blue15 = blue15;
    }

    public Short getBlue16() {
        return blue16;
    }

    public void setBlue16(Short blue16) {
        this.blue16 = blue16;
    }
}